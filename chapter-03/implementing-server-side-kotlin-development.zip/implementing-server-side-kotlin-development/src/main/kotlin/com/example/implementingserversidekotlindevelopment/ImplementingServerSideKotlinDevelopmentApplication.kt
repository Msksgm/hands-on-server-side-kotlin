package com.example.implementingserversidekotlindevelopment

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ImplementingServerSideKotlinDevelopmentApplication

fun main(args: Array<String>) {
	runApplication<ImplementingServerSideKotlinDevelopmentApplication>(*args)
}

package com.example.implementingserversidekotlindevelopment

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ImplementingServerSideKotlinDevelopmentApplicationTests {

	@Test
	fun contextLoads() {
	}

}
